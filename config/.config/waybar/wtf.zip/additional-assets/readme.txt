make sure to install every single font or waybar will break.
